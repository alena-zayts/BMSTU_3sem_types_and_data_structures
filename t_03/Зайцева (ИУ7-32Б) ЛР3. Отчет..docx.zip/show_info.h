#ifndef SHOW_INFO_H
#define SHOW_INFO_H

#include "main_header.h"

void show_info(void);

#endif // SHOW_INFO_H
