#ifndef MAIN_HEADER_H
#define MAIN_HEADER_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <inttypes.h>
#include <sys/time.h>

#define MAXNSHOWN 20
#define EPS 1e-6

#define OK 0
#define ERRMEM -1
#define ERRVALUE -2

#endif // MAIN_HEADER_H
